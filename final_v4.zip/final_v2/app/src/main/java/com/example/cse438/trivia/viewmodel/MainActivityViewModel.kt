package com.example.cse438.trivia.viewmodel

import androidx.lifecycle.ViewModel

class MainActivityViewModel : ViewModel() {
    var isSigningIn: Boolean = false
}