package com.example.cse438.trivia.data

data class Genres(
    val results : List<Int>
)