package com.example.cse438.trivia.data

data class Artist(
    val id : String,
    val name : String

)
