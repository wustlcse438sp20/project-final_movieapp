package com.example.cse438.trivia

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.cse438.trivia.adapter.PlaylistDetailAdapter
import com.example.cse438.trivia.data.JoinedData
import kotlinx.android.synthetic.main.activity_showplaylist.*

//we conduct join operations here
class ShowPlaylist() : AppCompatActivity() {
    //var joinedDataList: ArrayList<JoinedData> = ArrayList<JoinedData>()
    lateinit var viewModel: PlaylistViewModel
    var joinedData: ArrayList<JoinedData> = ArrayList()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_showplaylist)
    }

    override fun onStart() {
        super.onStart()
        val playlistId= intent.getStringExtra("playlistId")
        viewModel = ViewModelProviders.of(this).get(PlaylistViewModel::class.java)
        showplaylist_recycler_view.layoutManager = LinearLayoutManager(applicationContext)
        var playlistdetailAdapter = PlaylistDetailAdapter(joinedData, viewModel)
        showplaylist_recycler_view.adapter= playlistdetailAdapter
//        viewModel.updateId(playlistId.toInt())
        viewModel.getData(playlistId.toInt())
        viewModel!!.joinedData.observe(this, Observer {
            this.joinedData.clear()
            this.joinedData.addAll(it)
            playlistdetailAdapter.notifyDataSetChanged()
        })

   }
}
