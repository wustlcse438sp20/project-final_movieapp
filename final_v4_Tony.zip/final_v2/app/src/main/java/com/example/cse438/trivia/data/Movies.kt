package com.example.cse438.trivia.data

data class Movies(
    val results : List<PopularMovie>
)
