package com.example.cse438.trivia.data

data class Album(
        val id : Int,
        val title : String,
        val cover : String,
        val genre : String,
        val actors : String,
        val language : String,
        val release_date : String
)